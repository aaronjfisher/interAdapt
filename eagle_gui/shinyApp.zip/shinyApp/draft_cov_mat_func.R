trtEff<-0

p1c<- 0.33
p2c<- 0.12
p1t<- p1c + trtEff
p2t<- p2c + trtEff

get_ss_ss1_ss2<-function(){
	p1 <- p1_user_defined
	p2 <- 1-p1

	k_star <- last_stage_subpop_2_enrolled_adaptive_design
	K<-total_number_stages
	just_s1<- K-k_star

	ss1star<-per_stage_sample_size_combined_adaptive_design_user_defined
	nkstar<-per_stage_sample_size_when_only_subpop_2_enrolled_adaptive_design_user_defined

	ss<-rep(NA,K) #will hold the cumulative sample size in both pops.
	ss[1:k_star]<- (1:k_star)*ss1star
	ss1<-ss*p1 #cumulative sample size in subpop1
	ss2<-ss*p2 #cumulative sample size in subpop2
	if(just_s1>0){
		ss[(k_star+1):(K)] <-	ss[k_star]+nkstar*(1:just_s1)
		ss2[(k_star+1):(K)] <- 0
		ss1[(k_star+1):(K)] <- ss[k_star]*p1 + nkstar*(1:just_s1)
	}

	return(list('ss'=ss,'ss1'=ss1,'ss2'=ss2))
}
	                                  
	        ####### #  ##  #          
	        # ##### # # # #           
	        # ###   # ## # #          
	        # # #   # #  # #          
	        # # ### ### ## #          
	  #  ## # ##### # # # #    #  ##  
	  #  ## # ###    # # # #   #  ##  
	  ###   #####   ########   ###    

#Top left is C, lower right is S.
#Matrix will be KxK, even if not trial uses the whole thing when k* < K.
get_cov_mat<-function(p1t,p1c,p2t,p2c) {
	p1 <- p1_user_defined
	p2 <- 1-p1

	ssList<-get_ss_ss1_ss2()
	ss1<-ssList$ss1; ss2<-ssList$ss2; ss<-ssList$ss
	
	cov_matrix_C <- diag(K)
	cov_matrix_S <- diag(K)
	for(i in 1:K){
		for(j in 1:K){
			cov_matrix_C[i,j] <- sqrt(min(ss[i],ss[j])/max(ss[i],ss[j]))
			cov_matrix_S[i,j] <- sqrt(min(ss1[i],ss1[j])/max(ss1[i],ss1[j]))
		}
	}
	
	#next two terms are the term in square brackets in page 6 of MISTIE paper.
	cov_CS_numerator  <- p1*(p1c*(1-p1c)/r1c + p1t*(1-p1t)/r1t)
	cov_CS_denominator<- cov_CS_numerator + p2*(p2c*(1-p2c)/r2c + p2t*(1-p2t)/r2t)
	#lower left of the eventual cov mat.
	cov_matrix_CS <- cov_matrix_S * sqrt(cov_CS_numerator/cov_CS_denominator)
	
	cov_matrix<-diag(K+K)
	rownames(cov_matrix)<-
	colnames(cov_matrix)<-c(paste0('C',1:K),paste0('S',1:K))
	cov_matrix[1:K,1:K]<-cov_matrix_C
	cov_matrix[(K+1):(K+K),(K+1):(K+K)]<-cov_matrix_S
	cov_matrix[(K+1):(K+K),1:K]<-   cov_matrix_CS   #lower left
	cov_matrix[1:K,(K+1):(K+K)]<- t(cov_matrix_CS) #upper right

	return(cov_matrix)
}

per_stage_sample_size_FC<-90
per_stage_sample_size_FS<-90
get_se_diff_means<-function(pop='C',p1t=p1t, p1c=p1c, p2t=p2t, p2c=p2c){
	p1 <- p1_user_defined
	p2 <- 1-p1

	ssAD<-get_ss_ss1_ss2()
	ssFC<-per_stage_sample_size_FC*(1:K)
	ssFS<-per_stage_sample_size_FS*(1:K)

	#this will be multiplied by (1/n), where n varies for C and S.
	varMeansCUns<-(	  p1 * (p1c*(1-p1c)/r1c + p1t*(1-p1t)/r1t) 
						+ p2 * (p2c*(1-p2c)/r2c + p2t*(1-p2t)/r2t)  )
	varMeansSUns<-(p1c*(1-p1c)/r1c + p1t*(1-p1t)/r1t)
	
	varMeansADC<-	varMeansCUns/ssAD$ss
	varMeansADS<-	varMeansSUns/ssAD$ss1
	varMeansFC<-	varMeansCUns/ssFC
	varMeansFS<-	varMeansSUns/ssFS

	varMeans<-cbind(AD_C=varMeansADC,AD_S=varMeansADS,FC=varMeansFC,FS=varMeansFS)
	return(sqrt(varMeans))
}


#for combined C, fixed trial



trtEff<-.12
p1c<- 0.33
p2c<- 0.12
p1t<- p1c + trtEff
p2t<- p2c + trtEff

cm<-get_cov_mat(p1t=p1t, p1c=p1c, p2t=p2t, p2c=p2c)
se_diff_means<-get_se_diff_means(p1t=p1t, p1c=p1c, p2t=p2t, p2c=p2c)

get_prob_stop_fixed<-function(trial='FC',varMeans,cov_matrix=cov_matrix)

if(trial='FC'){
	HOC_boundary_mat<- t(fixed_H0C_design_sample_sizes_and_boundaries_table()[[1]][c("H0C Efficacy Boundary", "H0C Futility Boundary"), ])
	eff<-HOC_boundary_mat[,'H0C Efficacy Boundary']
	fut<-HOC_boundary_mat[,'H0C Futility Boundary']
	cm<-cov_matrix[1:K,1:K]
}
if(trial='FS'){
	HOS_boundary_mat<- t(fixed_H01_design_sample_sizes_and_boundaries_table()[[1]][c("H01 Efficacy Boundary", "H01 Futility Boundary"), ])
	eff<-HOS_boundary_mat[,'H01 Efficacy Boundary']
	fut<-HOS_boundary_mat[,'H01 Futility Boundary']
	cm<-cov_matrix[(1+K):(K+K),(1+K):(K+K)]
}
if(trial='AD'){
	k_star<-total_number_stages
	boundary_mat<- ????;
	eff_C<-boundary_mat[,'H0C Efficacy Boundary']
	fut_C<-boundary_mat[,'H0C Futility Boundary']
	eff_S<-boundary_mat[,'H0C Efficacy Boundary']
	fut_S<-boundary_mat[,'H0C Futility Boundary']
	cmInd<-c(1:k_star,(K+1):(K+K))
	cm<-cov_matrix[cmInd,cmInd]
}

p_eff_stop_no_futility<-c()
p_eff_stop<-c()
p_fut_stop<-c()

p_eff_stop_no_futility[1]<-pnorm(eff[1],mean=trtEff,sd=1,lower.tail=FALSE)
p_eff_stop[1]<-pnorm(eff[1],mean=trtEff/se_diff_means[1,'C'],sd=1,lower.tail=FALSE)
p_fut_stop[1]<-pnorm(fut[1],mean=trtEff/se_diff_means[1,'C'],sd=1,lower.tail=TRUE)
for(k in 2:K){
	p_eff_stop_no_futility[k]<-pmvnorm(  
		mean=trtEff/se_diff_means[1:k,'C'],
		upper=c(eff[1:(k-1)],Inf),
		lower=c(rep(-Inf,k-1),eff[k]),
		sigma=cm[1:k,1:k]  )
	
	p_eff_stop[k]<-pmvnorm(  
		mean=trtEff/se_diff_means[1:k,'C'],
		upper=c(eff[1:(k-1)],Inf),
		lower=c(fut[1:k-1],eff[k]),
		sigma=cm[1:k,1:k]  )

	p_fut_stop[k]<-pmvnorm(  
		mean=trtEff/se_diff_means[1:k,'C'],
		upper=c(eff[1:(k-1)],fut[k]),
		lower=c(fut[1:k-1],-Inf),
		sigma=cm[1:k,1:k]  )
}


sum(p_eff_stop[1:k_star])#alpha
sum(p_eff_stop)
sum(p_fut_stop)
sum(p_eff_stop)+sum(p_fut_stop)


#Randomization Rates
r1c <- 1/2 
r2c <- 1/2 
r1t <- 1/2
r2t <- 1/2

se2_ck_no_n<-p1*(p1c*(1-p1c)/r1c + p1t*(1-p1t)/r1t ) +  p2*(p2c*(1-p2c)/r1c + p2t*(1-p2t)/r1t )
se_ck<-sqrt(se_ck_no_n/ss[1:k_star])
.125/se_ck


